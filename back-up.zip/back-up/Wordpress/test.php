session_start();
require_once "config.php";

$stmt->prepare("");
$stmt->bind_param();
$stmt->execute():
$stmt->store_result();